# Zets-Hair-Japan-Addons
Kawaii skins and eyes!

# Dependencies
[Zetsukaze's Hair Extensions](https://github.com/Zetsukaze/Zets-Hair-Extensions)

# Usage Guide
Follow the instructions for the above repository, this is not meant to be a standalone mod!
