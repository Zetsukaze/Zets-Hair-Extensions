# Zets-Hair-Cata-plusplus
Adds hairs, eyes and skin for the Cata++ mod, used with DeadPeopleTileset

# Dependencies
[Zetsukaze's Hair Extensions](https://github.com/Zetsukaze/Zets-Hair-Extensions)

# Usage Guide
Follow the instructions for the above repository, this is not meant to be a standalone mod!
